// E2E test – saucedemo
// Accessibility smoke using cypress-axe
import { Sel } from '../support/selectors.js';

describe('A11y smoke', { tags: ['@a11y', '@quality'] }, () => {
  it('inventory page has no critical violations', () => {
    cy.fixture('users').then(({ standard }) => cy.login(standard.username, standard.password));
    cy.visit('/inventory.html');
    cy.injectAxe();
    // Stabilize CI: color-contrast in headless can be noisy due to font rendering
    cy.configureAxe({ rules: [{ id: 'color-contrast', enabled: false }] });
    cy.checkA11y(undefined, { includedImpacts: ['critical'] });
  });
});
