// Basic RESTful Booker sanity
describe('Ref: Security sanity', () => {
  it('disallows update without token', () => {
    cy.request({
      method: 'PUT',
      url: 'https://restful-booker.herokuapp.com/booking/1',
      body: { firstname: 'Nope' },
      failOnStatusCode: false,
    }).its('status').should('be.oneOf', [401, 403, 405]);
  });

  it('has CORS headers on GET', () => {
    cy.request({
      method: 'GET',
      url: 'https://restful-booker.herokuapp.com/booking/1',
      failOnStatusCode: false,
    }).then((resp) => {
      expect(resp.headers).to.have.property('access-control-allow-origin');
    });
  });
});
