function parsePrice(txt){ return Number(txt.replace(/[^0-9.]/g,'')); }

describe('Ref: Catalog sorting', () => {
  beforeEach(() => {
    cy.login();
    cy.ensureOnInventory();
  });

  it('sorts by Price (low to high)', () => {
    cy.get('[data-test="product_sort_container"]').select('Price (low to high)');
    cy.get('.inventory_item_price').then(($prices) => {
      const values = [...$prices].map(el => parsePrice(el.innerText));
      const sorted = [...values].sort((a,b)=>a-b);
      expect(values, 'prices are sorted asc').to.deep.equal(sorted);
    });
  });
});
