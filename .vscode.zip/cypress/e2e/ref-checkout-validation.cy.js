describe('Ref: Checkout validation', () => {
  beforeEach(() => {
    cy.login();
    cy.ensureOnInventory();
    cy.openCart();
    cy.contains('button', 'Checkout').click();
  });

  it('requires first name, last name and postal code', () => {
    cy.contains('input,button', 'Continue').click();
    cy.get('[data-test="error"]').should('contain.text', 'First Name');
    cy.get('[data-test="firstName"]').type('A');
    cy.contains('input,button', 'Continue').click();
    cy.get('[data-test="error"]').should('contain.text', 'Last Name');
    cy.get('[data-test="lastName"]').type('B');
    cy.contains('input,button', 'Continue').click();
    cy.get('[data-test="error"]').should('contain.text', 'Postal Code');
  });
});
