// E2E test – saucedemo
// Basic visual regression on inventory list (CI-friendly)

const onCI = !!Cypress.env('CI');

describe('Visual regression', { tags: ['@visual', '@quality'] }, () => {
  it('inventory list stable layout', () => {
    cy.fixture('users').then(({ standard }) => cy.login(standard.username, standard.password));
    cy.viewport(1280, 720);
    cy.visit('/inventory.html');

    // Wait for images/fonts/rendering to settle
    cy.get('.inventory_list').should('be.visible');
    cy.wait(500);

    // Reduce flake: disable CSS animations and caret blinking
    cy.document().then((doc) => {
      const style = doc.createElement('style');
      style.innerHTML = `
        * { animation: none !important; transition: none !important; caret-color: transparent !important; }
      `;
      doc.head.appendChild(style);
    });

    // Hide potentially dynamic elements (e.g., cart badge count)
    cy.get('body').then(($body) => {
      const style = document.createElement('style');
      style.innerHTML = `.shopping_cart_badge { visibility: hidden !important; }`;
      $body[0].appendChild(style);
    });

    // Snapshot with a small threshold on CI
    const opts = {
      failureThreshold: Number(Cypress.env('visualThreshold') || (onCI ? 0.03 : 0.02)),
      failureThresholdType: 'percent',
      capture: 'viewport'
    };
    cy.matchImageSnapshot('inventory-list', opts);
  });
});