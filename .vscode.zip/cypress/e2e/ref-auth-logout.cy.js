describe('Ref: Logout', () => {
  it('logs out via burger menu', () => {
    cy.login();
    cy.logoutViaMenu();
  });
});
