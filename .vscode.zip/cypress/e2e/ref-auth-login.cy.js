describe('Ref: Login', () => {
  it('logs in as standard_user (happy path)', () => {
    cy.visit('/');
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('secret_sauce', { log: false });
    cy.get('[data-test="login-button"]').click();
    cy.url().should('match', /inventory/);
    cy.get('.inventory_list').should('be.visible');
  });

  it('shows error for locked_out_user (negative)', () => {
    cy.visit('/');
    cy.get('[data-test="username"]').type('locked_out_user');
    cy.get('[data-test="password"]').type('secret_sauce', { log: false });
    cy.get('[data-test="login-button"]').click();
    cy.get('[data-test="error"]').should('contain.text', 'locked out');
  });
});
