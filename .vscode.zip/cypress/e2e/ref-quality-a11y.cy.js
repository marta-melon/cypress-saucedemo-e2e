describe('Ref: A11y smoke', () => {
  it('inventory page has no critical violations', () => {
    cy.login();
    cy.ensureOnInventory();
    cy.a11ySmoke(); // no-op if plugin not installed
  });
});
