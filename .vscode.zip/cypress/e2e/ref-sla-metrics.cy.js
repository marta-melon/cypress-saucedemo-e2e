describe('Ref: SLA metrics', () => {
  it('GET /booking within SLA', () => {
    const start = Date.now();
    cy.request('https://restful-booker.herokuapp.com/booking')
      .then(() => {
        const elapsed = Date.now() - start;
        expect(elapsed).to.be.lessThan(2000);
      });
  });
});
