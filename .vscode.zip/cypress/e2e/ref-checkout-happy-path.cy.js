describe('Ref: Checkout happy path', () => {
  it('purchases a single item successfully', () => {
    cy.login();
    cy.ensureOnInventory();
    cy.addItem(0);
    cy.openCart();
    cy.contains('button', 'Checkout').click();
    cy.get('[data-test="firstName"]').type('Jane');
    cy.get('[data-test="lastName"]').type('Doe');
    cy.get('[data-test="postalCode"]').type('00-001');
    cy.contains('input,button', 'Continue').click();
    cy.contains('button', 'Finish').click();
    cy.contains('.complete-header, h2', /thank you for your order/i).should('be.visible');
  });
});
