\
// cypress/support/commands.js

// Safe visit that can try '/?/path' fallback when the site returns 404 / odd routing.
Cypress.Commands.add('safeVisit', (path) => {
  const pathOnly = path.startsWith('http') ? new URL(path).pathname : path;
  const first = pathOnly;
  const fallback = pathOnly.startsWith('/?/') ? pathOnly : '/?' + pathOnly;

  // Try main path
  cy.visit(first, { failOnStatusCode: false, timeout: 90000 });
  cy.location('pathname', { timeout: 20000 }).then((p) => {
    if (!p.includes(first.replace(/^\//, '').replace(/^\?\//, ''))) {
      // Try fallback
      cy.visit(fallback, { failOnStatusCode: false, timeout: 90000 });
    }
  });
});

// Ensure we're on the inventory page, with robust routing
Cypress.Commands.add('ensureOnInventory', () => {
  // If already there, just assert
  cy.location('pathname', { timeout: 10000 }).then((p) => {
    if (p && p.includes('/inventory')) return;
    cy.safeVisit('/inventory.html');
  });
  // Wait for inventory list/sort control
  cy.get('[data-test="product_sort_container"], .inventory_list', { timeout: 20000 }).should('exist');
});

// UI Login with session caching
Cypress.Commands.add('login', (username = 'standard_user', password = 'secret_sauce') => {
  const key = ['ui-login', username, password].join(':');
  cy.session(key, () => {
    cy.visit('/', { failOnStatusCode: false, timeout: 90000 });
    cy.get('[data-test="username"]', { timeout: 20000 }).clear().type(username, { log: false });
    cy.get('[data-test="password"]').clear().type(password, { log: false });
    cy.get('[data-test="login-button"]').click();
    // If error appears (locked user), do not force inventory
    cy.get('body', { timeout: 15000 }).then(($b) => {
      const hasError = $b.find('[data-test="error"]').length > 0;
      if (!hasError) {
        cy.ensureOnInventory();
      }
    });
  }, {
    validate() {
      // Consider session valid if we can hit inventory and see sort control
      cy.visit('/inventory.html', { failOnStatusCode: false, timeout: 90000 });
      cy.get('body', { timeout: 10000 }).then(($b) => {
        const ok = $b.find('[data-test="product_sort_container"], .inventory_list').length > 0;
        if (!ok) {
          // fallback
          cy.visit('/?/inventory.html', { failOnStatusCode: false, timeout: 90000 });
          cy.get('[data-test="product_sort_container"], .inventory_list', { timeout: 15000 }).should('exist');
        }
      });
    }
  });
});

// Logout via burger menu; also expose alias for your tests
Cypress.Commands.add('logoutViaMenu', () => {
  // make sure we're on inventory to see burger menu
  cy.get('body').then(($b) => {
    if ($b.find('#react-burger-menu-btn, [data-test="react-burger-menu-btn"]').length === 0) {
      cy.ensureOnInventory();
    }
  });
  cy.get('#react-burger-menu-btn, [data-test="react-burger-menu-btn"]', { timeout: 15000 }).click();
  cy.get('#logout_sidebar_link, a#logout_sidebar_link, [data-test="logout-sidebar-link"]', { timeout: 15000 }).click({ force: true });
  cy.location('pathname', { timeout: 20000 }).should('eq', '/');
  cy.get('[data-test="login-button"]', { timeout: 20000 }).should('be.visible');
});

// Alias expected by your specs
Cypress.Commands.add('logout', () => cy.logoutViaMenu());

// Open cart robustly
Cypress.Commands.add('openCart', () => {
  // Use header cart link if available
  cy.get('body').then(($b) => {
    const hasLink = $b.find('[data-test="shopping-cart-link"], .shopping_cart_link').length > 0;
    if (hasLink) {
      cy.get('[data-test="shopping-cart-link"], .shopping_cart_link').first().click({ force: true });
    } else {
      // fallback: direct navigate
      cy.safeVisit('/cart.html');
    }
  });
  // Verify on cart
  cy.location('pathname', { timeout: 15000 }).then((p) => {
    if (!p.includes('/cart')) {
      cy.safeVisit('/cart.html');
    }
  });
  cy.get('.cart_list, [data-test="cart-list"]', { timeout: 15000 }).should('exist');
});

// Add/remove items by name (best-effort generic helpers)
Cypress.Commands.add('addItem', (name) => {
  if (!name) throw new Error('addItem requires a product name');
  cy.contains('.inventory_item', name, { timeout: 15000 })
    .should('exist')
    .within(() => {
      cy.get('button, [data-test^="add-to-cart"]', { timeout: 10000 }).first().click();
    });
});

Cypress.Commands.add('removeItem', (name) => {
  if (!name) throw new Error('removeItem requires a product name');
  cy.contains('.inventory_item', name, { timeout: 15000 })
    .should('exist')
    .within(() => {
      cy.get('button, [data-test^="remove"]', { timeout: 10000 }).first().click();
    });
});
