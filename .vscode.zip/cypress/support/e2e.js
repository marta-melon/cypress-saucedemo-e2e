// cypress/support/e2e.js
// Handle 3rd party errors without failing specs
Cypress.on('uncaught:exception', () => false);

import './commands';

// Optional plugins - load if installed
try {
  // a11y
  // eslint-disable-next-line import/no-extraneous-dependencies
  require('cypress-axe');
} catch (e) {
  // Provide no-op helpers to avoid test crashes if plugin is missing
  Cypress.Commands.add('injectAxe', () => {});
  Cypress.Commands.add('checkA11y', () => {});
}

try {
  // visual snapshots
  // eslint-disable-next-line import/no-extraneous-dependencies
  const { addMatchImageSnapshotCommand } = require('@simonsmith/cypress-image-snapshot');
  if (typeof addMatchImageSnapshotCommand === 'function') {
    addMatchImageSnapshotCommand();
  }
} catch (e) {
  // no-op fallback
  Cypress.Commands.add('matchImageSnapshot', () => {});
}
